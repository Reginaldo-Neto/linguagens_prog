REGINALDO GREGÓRIO DE SOUZA NETO
a61482

Modo de usar o app prolog.

Consutar o arquivo "Classes.pl"
EXEMPLO DE USO
O "//" significa comentário e não um comando de fato
Lembre-se de nunca utilizar letras MAIÚSCULAS
CADA LINHA REPRESENTA UMA ENTRADA DE COMANDO:

init.
2.
escola.
[(string, nome), (int, alunos)].
[op1()].
2.
professor.
[(string, nome), (int, idade), (float, peso)].
[daraula(), ler(), corrigir()].
2.
testevazia.
[]. //Caso queira representar que uma classe nao possui atributos é preciso usar os []
[]. //O mesmo se aplica para os métodos

//Como listar todas as classes criadas

1.

//Como contar os atributos de cada classe.

4. 
escola.
4.
professor.
4.
testevazia.

//Como inserir relações

3.
professor.
0.
1.
0.
testevazia.

3.
escola.
6.
2.
1.
professor.

//caso o nome de qualquer uma das duas classes seja digitado errado, o código deve retornar o warning acusando isso

//Por fim, basta digitar 5. que o diagrama será gerado na pasta padrão do prolog em sua máquina.
